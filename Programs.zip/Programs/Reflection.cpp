/* Reflection Programe By Vishal Nagda, Using IDE DEV-C++ 4.9.9.2 */

/* Reflection's Matrix
	
	Rf[3][3] = { {1, 0, 0}, {0, -1, 0}, {0, 0, 1} };
	
*/

#include<graphics.h>

int main()
{
    int x=200,y=200,x1=150,y1=300,x2=300,y2=300;
    int tri[3][3]={{x,x1,x2},{y,y1,y2},{1,1,1}},ref[3][3]={{1,0,0},{0,-1,0},{0,0,1}},ans[3][3];
    
    initwindow(800,600,"Reflection");
    
    line(tri[0][0],tri[1][0],tri[0][1],tri[1][1]);
    line(tri[0][1],tri[1][1],tri[0][2],tri[1][2]);
    line(tri[0][2],tri[1][2],tri[0][0],tri[1][0]);
    
    for(int i=0;i<3;i++)
    for(int j=0;j<3;j++)
    {
      ans[i][j]=0;
      for(int k=0;k<3;k++)
        ans[i][j]+=ref[i][k]*tri[k][j];
    }
    
    getch();
    //cleardevice();
    
    line(ans[0][0],ans[1][0],ans[0][1],ans[1][1]);
    line(ans[0][1],ans[1][1],ans[0][2],ans[1][2]);
    line(ans[0][2],ans[1][2],ans[0][0],ans[1][0]);
    
    while(!kbhit());
    return 0;
}
