/* Shearing Programme Written By VISHAL NAGDA, IDE : DEV-C++ 4.9.9.2 */

/* Shearing's Matrix
	
	Sh[3][3] = { {1, sx, 0}, {sy, 1, 0}, {0, 0, 1} };
	
*/

#include<graphics.h>

int main()
{
    double x=200,y=200,x1=550,y1=200,x2=550,y2=400,x3=200,y3=400,sx=.1,sy=0.1;
    double rect[3][4]={{x,x1,x2,x3},{y,y1,y2,y3},{1,1,1,1}},shr[3][3]={{1,sx,0},{sy,1,0},{0,0,1}},ans[3][4];
    int i,j,k;
    initwindow(800,600,"Shearing");
    
    line((int)rect[0][0],(int)rect[1][0],(int)rect[0][1],(int)rect[1][1]);
    line((int)rect[0][1],(int)rect[1][1],(int)rect[0][2],(int)rect[1][2]);
    line((int)rect[0][2],(int)rect[1][2],(int)rect[0][3],(int)rect[1][3]);
    line((int)rect[0][3],(int)rect[1][3],(int)rect[0][0],(int)rect[1][0]);
    
    for(i=0;i<3;i++)
    for(j=0;j<4;j++)
    {
        ans[i][j]=0;
        for(k=0;k<3;k++)
           ans[i][j]+=shr[i][k]*rect[k][j];
    }

    getch();
    cleardevice();
    
    line((int)ans[0][0],(int)ans[1][0],(int)ans[0][1],(int)ans[1][1]);
    line((int)ans[0][1],(int)ans[1][1],(int)ans[0][2],(int)ans[1][2]);
    line((int)ans[0][2],(int)ans[1][2],(int)ans[0][3],(int)ans[1][3]);
    line((int)ans[0][3],(int)ans[1][3],(int)ans[0][0],(int)ans[1][0]);
    
    while(!kbhit());    
    return 0;
}
