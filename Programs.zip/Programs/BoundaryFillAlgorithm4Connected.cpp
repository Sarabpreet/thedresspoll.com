/* Boundary Fill Algorithm (4 Connected). Programmed By Vishal Nagda, Using DEV C++ 4.9.9.2 */

/* Boundary Fill's Algorithm

   * Get x & y coordinate and fill_color & boundary_color.
   * Check IF getpixel(x,y)!=boundary_color AND getpixel(x,y)!=fill_color THEN :
     - Plot pixel at x & y coordinate with fill_color.
	 - Call the function recursively with x+1 & y coordinate and fill_color & boundary_color parameter.
	 - Call the function recursively with x & y+1 coordinate and fill_color & boundary_color parameter.
	 - Call the function recursively with x-1 & y coordinate and fill_color & boundary_color parameter.
	 - Call the function recursively with x & y-1 coordinate and fill_color & boundary_color parameter.
   
*/

#include<graphics.h>

void boundary_fill(int, int, int, int);

int main()
{
    initwindow(800,600,"Boundary Fill (4 Connected)");
    setcolor(3);
    circle(400,300,100);
    boundary_fill(400,300,2,3);
    setcolor(2);
    rectangle(100,100,200,200);
    boundary_fill(150,150,15,2);
    while(!kbhit());
    return 0;
}

void boundary_fill(int x, int y, int fill_color, int boundary_color)
{
     if(getpixel(x,y)!=boundary_color && getpixel(x,y)!=fill_color)
     {
        putpixel(x,y,fill_color);
        boundary_fill(x+1,y,fill_color,boundary_color);
        boundary_fill(x,y+1,fill_color,boundary_color);
        boundary_fill(x-1,y,fill_color,boundary_color);
        boundary_fill(x,y-1,fill_color,boundary_color);
     }
}
