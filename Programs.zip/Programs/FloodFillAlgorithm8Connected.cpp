/* Flood Fill Algorithm (8 Connected). Programmed By Vishal Nagda, Using DEV C++ 4.9.9.2 */

/* Flood Fill Algorithm

  * Get x & y coordinate and old_color & new_color.
  * Check IF getpixel(x,y)==old_color THEN :
    - Plot pixel at x & y coordinate with new_color.
	- Call the function recursively with x+1 & y coordinate and old_color & new_color parameter.
	- Call the function recursively with x-1 & y coordinate and old_color & new_color parameter.
	- Call the function recursively with x & y+1 coordinate and old_color & new_color parameter.
	- Call the function recursively with x & y-1 coordinate and old_color & new_color parameter.
	- Call the function recursively with x+1 & y+1 coordinate and old_color & new_color parameter.
	- Call the function recursively with x-1 & y-1 coordinate and old_color & new_color parameter.
	- Call the function recursively with x+1 & y-1, coordinate and old_color & new_color parameter.
	- Call the function recursively with x-1 & y+1 coordinate and old_color & new_color parameter.

*/

#include<graphics.h>

void flood_fill(int x, int y, int old_color, int new_color)
{
     if(getpixel(x,y)==old_color)
     {
        putpixel(x,y,new_color);
        flood_fill(x+1,y,old_color,new_color);
        flood_fill(x-1,y,old_color,new_color);
		flood_fill(x,y+1,old_color,new_color);
        flood_fill(x,y-1,old_color,new_color);
        flood_fill(x+1,y+1,old_color,new_color);
        flood_fill(x-1,y-1,old_color,new_color);
        flood_fill(x+1,y-1,old_color,new_color);
        flood_fill(x-1,y+1,old_color,new_color);
     }
}

int main()
{
    initwindow(800,600,"Flood Fill (8 Connected)");
    rectangle(200,200,400,400);
    flood_fill(201,201,getbkcolor(),-1);
    while(!kbhit());
    return 0;
}
