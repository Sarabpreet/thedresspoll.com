/* Bresenham's Line Drawing Algorithm */
/* Source Code Written By Vishal Nagda In DEV C++ 4.9.9.2 */

/* Bresenham's Line Drawing Algorithm

   * Get starting (x,y) & ending (x1,y1) coordinates.
   * Plot pixel at x & y coordinate.
   * Calculate delta x (dx = x1-x) & delta y (dy = y1-y).
   * Calculate p = 2*dy - dx.
   * Repeat from i=0 to i<=dx-1.
     - Check IF p<0 THEN : plot pixel at ++x & y coordinate and calculate p = p+(2*dy).
		OTHERWISE : Plot pixel at ++x & ++y and calculate p = p+(2*dy)-(2*dx).

*/

#include<graphics.h>

void bld(double,double,double,double);

int main()
{
    initwindow(800,600,"Bresenham's Line Drawing Algorithm");   
	
	bld(200,100,500,100);
    //bld(200,100,150,200);
    //bld(150,200,550,200);
    //bld(550,200,500,100);
	
    while(!kbhit());
    return 0;
}

void bld(double x,double y,double x1,double y1)
{
    putpixel((int)x,(int)y,-1);
    
    double dx=x1-x, dy=y1-y;
    double p=(2*dy)-dx, i=0;
    
    do{
        if(p<0)
        {
           putpixel((int)++x, (int)y, -1);
           p=p+(2*dy);
        }
        else
        {
           putpixel((int)++x, (int)++y, -1); 
           p=p+(2*dy)-(2*dx);
        }
    }while(++i<=(dx-1));
}
