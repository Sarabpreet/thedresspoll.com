/* Programe To Create House Using Line & Rectangle Function Of Graphics */
/* Source Code Written By Vishal Nagda In DEV C++ 4.9.9.2 */

#include<graphics.h>

int main()
{
    initwindow(720,450,"House");
    
    line(200,100,500,100);
    line(200,100,150,200);
    line(150,200,550,200);
    line(550,200,500,100);
    
    rectangle(200,200,500,340);
    rectangle(320,250,380,340);
    rectangle(400,250,440,290);
    
    line(400,260,440,260);
    line(400,270,440,270);
    line(400,280,440,280);
    
    while(!kbhit());
    return 0;
}
