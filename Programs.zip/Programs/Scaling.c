/* Scaling Programe By Vishal Nagda, Using IDE DEV-C++ 4.9.9.2 */

/* Scaling's Matrix
	
	S[3][3] = { {sx, 0, 0}, {0, sy, 0},{0, 0, 1} };
	
*/

#include<graphics.h>

int main()
{
    int x=200,y=300,x1=140,y1=360,x2=280,y2=360,i,j,k;
    double sx =1,sy=.7;
    double scal[3][3]={{sx,0,0},{0,sy,0},{0,0,1}},tri[3][3]={{x,x1,x2},{y,y1,y2},{1,1,1}},ans[3][3];;
    
    initwindow(800,600,"Scaling");
    
    line((int)tri[0][0],(int)tri[1][0],(int)tri[0][1],(int)tri[1][1]);
    line((int)tri[0][1],(int)tri[1][1],(int)tri[0][2],(int)tri[1][2]);
    line((int)tri[0][2],(int)tri[1][2],(int)tri[0][0],(int)tri[1][0]);
    
    getch();
         
    for(i=0;i<3;i++)
      for(j=0;j<3;j++)
      {
        ans[i][j]=0;
        for(k=0;k<3;k++)
         ans[i][j]+=scal[i][k]*tri[k][j];
      }
      
    cleardevice();
    
    
    line((int)ans[0][0],(int)ans[1][0],(int)ans[0][1],(int)ans[1][1]);
    line((int)ans[0][1],(int)ans[1][1],(int)ans[0][2],(int)ans[1][2]);
    line((int)ans[0][2],(int)ans[1][2],(int)ans[0][0],(int)ans[1][0]);
    
	
	//ANOTHER METHOD
    /*int x=100,y=150,x1=200,y1=200,sx=2,sy=2;
    initwindow(800,600,"Scaling");
    rectangle(x,y,x1,y1);
    
    x*=sx;
    y*=sy;
    
    x1*=sx;
    y1*=sy;
    getch();
    cleardevice();
    
    rectangle(x,y,x1,y1);*/
    
    while(!kbhit());
    return 0;
}
