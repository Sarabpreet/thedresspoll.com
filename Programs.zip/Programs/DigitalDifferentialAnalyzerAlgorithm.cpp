/* Digital Differential Analyzer (DDA) Algorithm */
/* Source Code Written By Vishal Nagda In DEV C++ 4.9.9.2 */

/* Algorithm Of Digital Differential Analyzer (DDA)

   * Get starting (x,y) & ending (x1,y1) codrinates of line.
   * Calculate delta x (dx=x1-x) and delta y (dy=dy1-y).
   * Check IF absolute value of delta x is greater then absolute value of delta y. THEN : set setps = absolute value of delta x.
	 Otherwise : set steps = absolute value of delta y.
   * draw pixel at x,y cordinate.
   * repeat from i=0 to i<steps :
     calculate x=x+(dx/steps) and y=y+(dy/steps).
	 draw pixel at x,y cordinate.
   
*/

#include<graphics.h>
#include<math.h>

void dda(double,double,double,double);

int main()
{
    initwindow(800,600,"Digital Differential Analyzer (DDA) Algorithm");
    dda(200,100,500,100);
    dda(200,100,150,200);
    dda(150,200,550,200);
    dda(550,200,500,100);
        
    while(!kbhit());
    return 0;
}

void dda(double x,double y,double x1,double y1)
{
    double dx=x1-x, dy=y1-y, steps;
    int i=0;
	
    if(fabs(dx)>fabs(dy))
       steps=fabs(dx);
    else
       steps=fabs(dy);
    
    putpixel(int(round(x)), int(round(y)), -1);
    
    while(i++<steps)
	   putpixel(int(round(x+=(dx/steps))), int(round(y+=(dy/steps))), -1);
}
