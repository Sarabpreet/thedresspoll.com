/* Mid Point Circle Algorithm */
/* Source Code Written By Vishal Nagda In DEV C++ 4.9.9.2 */

/* Symetric Point's Algorithm (Symetric Point Function's Algorithm Used In Mid Point Circle)

   * Get four coordinates (x,y,x1,y1).
   * Plot pixel at x+x1 & y+y1 coordinates.
   * Plot pixel at x-x1 & y-y1 coordinates.
   * Plot pixel at x+x1 & y-y1 coordinates.
   * Plot pixel at x-x1 & y+y1 coordinates.
   * Plot pixel at x+y1 & y+x1 coordinates.
   * Plot pixel at x-y1 & y-x1 coordinates.
   * Plot pixel at x+y1 & y-x1 coordinates.
   * Plot pixel at x-y1 & y+x1 coordinates.

*/

/* Mid Point Circle's Algorithm 

   * Get x & y coordinates and radius (r) of the circle.
   * Set x1 = 0 & y1 = radius and calculate p = 5/4-radius.
   * Repeat x1 to x1<=y1 :
     - Check IF p<0 THEN : call symetric point function with x, y, ++x1 & y1 parameter and calculate p=p+(2*x1)+1.
	   OTHERWISE : call symetric point function with x, y, ++x1 & --y1 parameter and calculate p=p+(2*x1)-(2*y1)+1

*/

#include<graphics.h>

void SymPt(int, int, int, int);
void mpc(int, int, int);

int main()
{
    initwindow(800,600,"Midpoint Circle Algorithm");
    
    mpc(400,300,200);
     
    while(!kbhit());
    
    return 0;
}

void mpc(int x, int y, int r)
{
    int x1=0, y1=r, p=5/4-r;
    
    while(x1<=y1)
    {
        if(p<0)
        {
           SymPt(x, y, ++x1, y1);
           p=p+2*x1+1;
        }
        else
        {
           SymPt(x, y, ++x1, --y1);
           p=p+2*x1-2*y1+1;
        }
    }
}

void SymPt(int x, int y, int x1, int y1)
{
     putpixel(x+x1, y+y1, -1);
     putpixel(x-x1, y-y1, -1);
     putpixel(x+x1, y-y1, -1);
     putpixel(x-x1, y+y1, -1);
     putpixel(x+y1, y+x1, -1);
     putpixel(x-y1, y-x1, -1);
     putpixel(x+y1, y-x1, -1);
     putpixel(x-y1, y+x1, -1);
}
