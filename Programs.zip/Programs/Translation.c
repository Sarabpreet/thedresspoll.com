/* Translation Program Written By VISHAL NAGDA, IDE DEV-C++ 4.9.9.2 */

/* Translation's Matrix
	
	T[3][3] = { {1, 0, tx}, {0, 1, ty}, {0, 0, 1} };
	
*/

#include<graphics.h>

int main()
{
    int x=100,y=150,x1=200,y1=200,tx=10,ty=20,ans[3][2],i,j,k;
    int tran[3][3]={{1,0,tx},{0,1,ty},{0,0,1}},rect[3][2]={{x,x1},{y,y1},{1,1}};
    initwindow(800,600,"Translation");
    rectangle(rect[0][0],rect[1][0],rect[0][1],rect[1][1]);
    getch();
    cleardevice();
    
    for(i=0;i<3;i++)
    for(j=0;j<2;j++)
    {
       ans[i][j]=0;
       for(k=0;k<3;k++)
         ans[i][j]+=tran[i][k]*rect[k][j];
    }
    
    rectangle(ans[0][0],ans[1][0],ans[0][1],ans[1][1]);
    
    while(!kbhit());
    return 0;
}
