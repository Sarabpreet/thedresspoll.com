/* Rotation Programe By Vishal Nagda, Using IDE DEV-C++ 4.9.9.2 */

/* Rotation's Matrix
	
	R[3][3] = {{cos(angle), -sin(angle), 0}, {sin(angle), cos(angle), 0}, {0, 0, 1} };
	
*/

#include<graphics.h>
#include<math.h>

int main()
{
    int x=200,y=300,x1=140,y1=360,x2=280,y2=360,i,j,k;
    double a=(-45*3.143)/180;
    double rot[3][3]={{cos(a),-sin(a),0},{sin(a),cos(a),0},{0,0,1}},tri[3][3]={{x,x1,x2},{y,y1,y2},{0,0,1}},ans[3][3];
    
    for(i=0;i<3;i++)
    for(j=0;j<3;j++)
    {
       ans[i][j]=0;
       for(k=0;k<3;k++)
         ans[i][j]+=rot[i][k]*tri[k][j];
    }
    
    initwindow(800,600,"Rotation");
    setcolor(2);
    line((int)tri[0][0],(int)tri[1][0],(int)tri[0][1],(int)tri[1][1]);
    setcolor(4);
    line((int)tri[0][1],(int)tri[1][1],(int)tri[0][2],(int)tri[1][2]);
    setcolor(6);
    line((int)tri[0][2],(int)tri[1][2],(int)tri[0][0],(int)tri[1][0]);
    
    getch();
    cleardevice();
    setcolor(2);
    line((int)ans[0][0],(int)ans[1][0],(int)ans[0][1],(int)ans[1][1]);
    setcolor(4);
    line((int)ans[0][1],(int)ans[1][1],(int)ans[0][2],(int)ans[1][2]);
    setcolor(6);
    line((int)ans[0][2],(int)ans[1][2],(int)ans[0][0],(int)ans[1][0]);
    
    while(!kbhit());
    return 0;
}
